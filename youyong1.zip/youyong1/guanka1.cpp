#include "guanka1.h"
#include "ui_guanka1.h"

guanka1::guanka1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::guanka1)
{
    ui->setupUi(this);
    map_guanka1 = QPixmap(":/map1/MAP.png");
}

guanka1::~guanka1()
{
    delete ui;
}

void guanka1::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,map_guanka1);
}

void guanka1::on_pushButton_clicked()
{
    emit g1_my_signal();
    this->hide();
}
