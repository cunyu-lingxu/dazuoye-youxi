#ifndef YOUXIJIEMIAN_H
#define YOUXIJIEMIAN_H

#include <QMainWindow>
#include <QPainter>
#include "guanka1.h"
#include "guanka2.h"

namespace Ui {
class youxijiemian;
}

class youxijiemian : public QMainWindow
{
    Q_OBJECT

public:
    explicit youxijiemian(QWidget *parent = 0);
    ~youxijiemian();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void reshow1();

    void reshow2();

    void on_pushButton_4_clicked();

signals:
    void my_singal();

protected:
    void paintEvent(QPaintEvent *);//重载函数

private:
    Ui::youxijiemian *ui;
    guanka1 * g1;
    guanka2 * g2;
    QPixmap bk_menu;
};

#endif // YOUXIJIEMIAN_H
