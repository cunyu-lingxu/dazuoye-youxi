#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "youxijiemian.h"


#include "QPainter"
class QPainter;
class QMouseEvent;
class QRect;


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
signals:
    void my_signal();//signals区域的函数必须是void类型，而且这些信号函数没有函数体，也就是说不可以自己定义这些信号函数，你只要声明它就够了，其它不用管，Qt内部自己弄
    void dianliangxinhao();




private slots:
    void on_pushButton_clicked();
    void reshow();
    void my_pushButton_clicked();



    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
private:
    youxijiemian * y;





public:
    void paintEvent(QPaintEvent *);//绘图
    void mousePressEvent(QMouseEvent *event);
    //void mouseReleaseEvent(QMouseEvent* event);
    void mouseMoveEvent(QMouseEvent *);//鼠标移动事件==》可以用于做触摸式的动作
public:
    QPaintEvent *m_paintevent;
    QPainter painter;
    bool m_pressflag;//判断按钮是否被点击
    bool m_touchflag;//鼠标滑动到按钮上
    QRectF rectbutton;//圆形按钮的外接矩形
    bool zhuanhuanjiemian;
signals:
    void cursorchanged(QPaintEvent *event);

};

#endif // MAINWINDOW_H
