#include "youxijiemian.h"
#include "ui_youxijiemian.h"

youxijiemian::youxijiemian(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::youxijiemian)
{
    ui->setupUi(this);
    g1 = new guanka1;
    g2 = new guanka2;
    bk_menu = QPixmap(":/map1/MAP.png");
}

youxijiemian::~youxijiemian()
{
    delete ui;
}

void youxijiemian::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap aj_bk_menu = bk_menu.scaled(600,400,Qt::KeepAspectRatio);
    painter.drawPixmap(0,0,aj_bk_menu);
}

void youxijiemian::on_pushButton_clicked()
{
    emit my_singal();
    this->hide();

}

void youxijiemian::on_pushButton_2_clicked()
{
    connect(g1,SIGNAL(g1_my_signal()),this,SLOT(show()));
    this->hide();
    g1->show();
}

void youxijiemian::on_pushButton_3_clicked()
{
    connect(g2,SIGNAL(g2_my_signal()),this,SLOT(show()));
    this->hide();
    g2->show();

}

void youxijiemian::on_pushButton_4_clicked()
{
    emit my_singal();
    this->hide();
}

void youxijiemian::reshow1(){
    g1->hide();
    this->show();
    setStyleSheet("background:red");
}

void youxijiemian::reshow2(){
    g2->hide();
    this->show();
    setStyleSheet("background:red");
}

