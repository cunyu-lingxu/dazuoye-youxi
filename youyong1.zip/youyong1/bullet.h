#ifndef BULLET_H
#define BULLET_H

#include <QPoint>
#include <QPixmap>
#include <QObject>
#include <QPainter>
#include <mainwindow.h>
#include <enemy.h>

class Bullet : public QObject
{
    Q_OBJECT
public:
    explicit Bullet(QObject *parent = nullptr);

public:
    Bullet(QPoint startPos, QPoint targetPos,  Enemy * target,
           MainWindow * game, const QPixmap &sprite = QPixmap(":/Arrow/Arrow1.png"));
    //~Bullet();
    void draw(QPainter * painter) const;
    void move();
    void setCurrentPos();
    QPoint currentPos() const;
    bool haveTarget();
private:
    QPoint _startPos;
    QPoint _targetPos;
    QPixmap _bullet;
    QPoint _currentPos;
    Enemy * _target;
    MainWindow * _game;
signals:

public slots:
    void hitTarget();
};

#endif // BULLET_H
