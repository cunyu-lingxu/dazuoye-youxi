#include "guanka2.h"
#include "ui_guanka2.h"

guanka2::guanka2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::guanka2)
{
    ui->setupUi(this);
}

guanka2::~guanka2()
{
    delete ui;
}

void guanka2::on_pushButton_clicked()
{
    /*QPixmap pix;
        pix = QPixmap(":/map2/MAP1.png");
        ui->pushButton->setFixedSize(pix.size());
        ui->pushButton->setMask(pix.mask());
        ui->pushButton->setStyleSheet("background-image: url(:/map2/MAP1.png)");*/

    emit g2_my_signal();
    this->hide();
}
