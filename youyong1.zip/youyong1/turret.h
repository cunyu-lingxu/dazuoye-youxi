#ifndef TURRET_H
#define TURRET_H


class turret
{
public:
    turret();
};

#endif // TURRET_H