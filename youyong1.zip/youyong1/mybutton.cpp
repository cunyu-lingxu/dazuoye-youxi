#include "mybutton.h"

MyButton::MyButton()
{

}
MyButton ::MyButton(QMainWindow * parent)
    :QPushButton(parent)
{
    QPixmap pixmap(":/my_button/my_button.png");
    resize(pixmap.size());
    <span class = "hljs-comment"></span>
    setMask(QBitmap(pixmap.mask()));
    setStyleSheet(<span class="hljs-string">"QPushButton{border-image: url(:/my_button/my_button.png);}"</span>);

}
void MyButton::enterEvent(QEvent *){
    setStyleSheet("QPushButton{border-image:url(:/my_button/my_button.png);}");
}
void MyButton::leaveEvent(QEvent *){
    setStyleSheet("QPushButton{border-image:url(:/my_button/my_button.png);}");
}
