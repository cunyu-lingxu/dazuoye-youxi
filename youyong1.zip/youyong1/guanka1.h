#ifndef GUANKA1_H
#define GUANKA1_H

#include <QMainWindow>
#include <QPainter>

namespace Ui {
class guanka1;
}

class guanka1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit guanka1(QWidget *parent = 0);
    ~guanka1();

private slots:
    void on_pushButton_clicked();
protected:
    void paintEvent(QPaintEvent *);

signals:
    void g1_my_signal();

private:
    Ui::guanka1 *ui;
    QPixmap map_guanka1;
};

#endif // GUANKA1_H
