#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "mainwindow.h"
#include"QPainter"
#include"QMouseEvent"
#include"QRectF"
#include"QDebug"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    y = new youxijiemian;



    m_pressflag = false;
    m_touchflag = false;
    rectbutton = QRectF(100,100,100,100);
    setMouseTracking(true);//设置鼠标可跟踪
    connect(this,SIGNAL(cursorchanged(QPaintEvent* )),this,SLOT(paintEvent(QPaintEvent*)));
    zhuanhuanjiemian = false;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::reshow(){
    y->hide();
    this->show();
}

void MainWindow::on_pushButton_clicked()
{
    connect(y,SIGNAL(my_singal()),this,SLOT(show()));
    this->hide();
    y->show();
}
void MainWindow::on_pushButton_2_clicked()
{
    connect(y,SIGNAL(my_singal()),this,SLOT(show()));
    this->hide();
    y->show();
}


void MainWindow::my_pushButton_clicked(){
    this->hide();
    y->show();
}

//绘图事件
void MainWindow::paintEvent(QPaintEvent *)
{
    painter.begin(this);
    QFont font1("宋体",15,QFont::Bold,true);
    font1.setCapitalization(QFont::SmallCaps);
    painter.setFont(font1);
    painter.setPen(Qt::blue);
    painter.drawText(150,150,tr("start"));
    painter.setPen(QPen(Qt::blue,4));//设置画笔形式
    //painter.setBrush(Qt::red);
    if(!m_pressflag && !m_touchflag){
        painter.drawEllipse(rectbutton);//画圆形状按钮==>矩形的内切圆
    }
    else if(m_pressflag)
    {
        painter.setBrush(Qt::red);
    }
    /*else if (!m_pressflag && m_touchflag)
    {
        //painter.begin(this);
        painter.setBrush(Qt::black);
    }*/
    painter.drawEllipse(rectbutton);
    painter.end();
    update();
}
//鼠标点击事件
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(rectbutton.contains(event->pos())){
        //qDebug()<<"buttton was clicked!";


        zhuanhuanjiemian = true;
        //emit dianliangxinhao();
        my_pushButton_clicked();


        m_pressflag = !m_pressflag;
    }

}
//鼠标释放事件
//鼠标移动事件
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{//鼠标移动事件==》可以用于做触摸式的动作
    QPoint n = event->pos();
    //qDebug()<<n;//鼠标移动位置
    if(rectbutton.contains(n))
    {
        //qDebug()<<"button was touched";
        m_touchflag = true;
    }
    else
    {
        m_touchflag =false;
    }
    emit cursorchanged(m_paintevent);//这个地方的信号函数的用法新手请注意，老司机请忽略
    //qDebug()<<"signal was emitted";
}
