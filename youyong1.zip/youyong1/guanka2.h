#ifndef GUANKA2_H
#define GUANKA2_H

#include <QMainWindow>

namespace Ui {
class guanka2;
}

class guanka2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit guanka2(QWidget *parent = 0);
    ~guanka2();

private slots:
    void on_pushButton_clicked();
signals:
    void g2_my_signal();

private:
    Ui::guanka2 *ui;
};

#endif // GUANKA2_H
