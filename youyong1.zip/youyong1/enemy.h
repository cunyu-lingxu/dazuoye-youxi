#ifndef ENEMY_H
#define ENEMY_H


class Enemy
{
public:
    Enemy();
};

#endif // ENEMY_H