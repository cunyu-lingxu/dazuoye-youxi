#include "turret.h"

turret::turret()
{

}
