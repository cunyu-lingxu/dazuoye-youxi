#include "waypoint.h"
#include <QPainter>
#include<QColor>
WayPoint::WayPoint(QPoint pos):
    m_pos(pos),
    m_nextWaypoint(NULL)
{

}
void WayPoint::setNextWayPoint(WayPoint *nextPoint)
{
    m_nextWaypoint = nextPoint;
}
WayPoint* WayPoint::nextWayPoint() const
{
    return m_nextWaypoint;
}
const QPoint WayPoint::pos() const
{
    return m_pos;
}

void WayPoint::draw(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::green);
    painter->drawEllipse(m_pos, 6, 6);
    painter->drawEllipse(m_pos, 2, 2);

    if (m_nextWaypoint)
        painter->drawLine(m_pos, m_nextWaypoint->m_pos);
    painter->restore();
}


