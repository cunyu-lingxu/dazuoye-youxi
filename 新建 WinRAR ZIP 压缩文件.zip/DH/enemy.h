#ifndef ENEMY_H
#define ENEMY_H


#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QPixmap>
#include <QSize>
#include <QVector2D>
#include "waypoint.h"
#include "turret.h"

class QPainter;
class Chapter;

/*class enemy : public QObject
{
public:
    enemy(WayPoint *StartWayPoint,Chapter *game );
    ~enemy();

    void getDamage(int damage);
    void getRemoved();  //移走死亡的敌人
    void draw(QPainter &painter) const;
    void getAttacked(Turret *attacker);
    void move();
    void canmove();
    void gotLostSight(Turret *attcker); //走出了塔的攻击范围
    QPoint pos() ;

private:
    bool    m_active;
    int     m_maxHp;//最大血量
    int     m_currentHp;//现在的血量
    qreal   m_walkingSpeed;
    qreal   m_ratationSprite;

    QPoint  m_pos;
    WayPoint *  m_destinationWayPoint;
    Chapter *   m_game;
    QList<Turret *>  m_attackedTowersList;

    QPixmap  m_sprite;
    static const QSize ms_fixedSize;


};
*/
class Enemy : public QObject
{
public:
    Enemy(QPoint pos);
    ~Enemy();

    void getDamage(int damage);
    void getRemoved();
    void draw(QPainter &painter) const;
    void getAttacked(Turret *attacker);
    void move();
    void canmove();
    void gotLostSight(Turret *attcker); //走出了塔的攻击范围
    QPoint pos() ;

private:
    int     _direction;
    bool    m_active;
    int     m_maxHp;//最大血量
    int     m_currentHp;//现在的血量
    qreal   m_walkingSpeed;
    qreal   m_ratationSprite;

    QPoint  m_pos;


    QList<Turret *>  m_attackedTowersList;

    QPixmap  m_sprite;
    static const QSize ms_fixedSize;

};
#endif // ENEMY_H
