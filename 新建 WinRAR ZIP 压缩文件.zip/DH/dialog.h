#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QPainter>
#include <towerbase.h>
#include <QMouseEvent>
#include <QWidget>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

signals:
    void sendSignal();

private slots:
    void on_pushButton_clicked();

protected:
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *event);

private:
    Ui::Dialog *ui;
    QPixmap _background;
    void loadTowerbase();
    QList<Towerbase> _tb;
};

#endif // DIALOG_H
