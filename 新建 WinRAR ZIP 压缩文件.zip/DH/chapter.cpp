#include "chapter.h"
#include "ui_chapter.h"
#include"waypoint.h"
#include "enemy.h"
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtDebug>

Chapter::Chapter(QWidget *parent) :
    QMainWindow(parent),
    e(QPoint(0,350)),
    ui(new Ui::Chapter)
{
    ui->setupUi(this);
    setMouseTracking(true);
    ui->centralwidget->setMouseTracking(true);

    _background = QPixmap(":/Map/MAP.jpg");
    loadTowerbase();
       //addWayPoints();

    connect(ui->pushButton, SIGNAL(clicked(bool)),this,SLOT(on_pushButton_clicked()));
    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(enemyMove()));
    timer->start((20));
}

Chapter::~Chapter()
{
    delete ui;
}

void Chapter::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap adback = _background.scaled(960, 640, Qt::KeepAspectRatio);
    painter.drawPixmap(0, 0, adback);
    for(int i=0 ; i<_tb.size() ; i++){
        _tb[i].draw(painter);
    }
    e.draw(painter);
         //painter.drawPixmap(800,500,_enemy);


}

void Chapter::mouseMoveEvent(QMouseEvent *event){
    QPoint mouse = event->pos();

    for(int i=0 ; i<_tb.size() ; i++){
        if(_tb[i].containPoint(mouse)){
            _tb[i].MouseEnter();
        }
        else{
            _tb[i].MouseLeave();
        }
    }

    update();
}


void Chapter::loadTowerbase(){
    QPoint pos[] = {
        QPoint(218, 170),
        QPoint(380, 154),

        QPoint(444, 154),
        QPoint(608, 170),

        QPoint(218, 296),
        QPoint(608, 296),

        QPoint(218, 400),
        QPoint(356, 400),

        QPoint(520, 446),
        QPoint(670, 446),

        QPoint(755, 386),
        QPoint(62, 286)
    };

    int len = sizeof(pos)/sizeof(pos[0]);

    for(int i=0 ; i<len ; ++i){
        _tb.push_back(pos[i]);
    }
}

void Chapter::mousePressEvent(QMouseEvent *event){
    QPoint mouse = event->pos();
    for(int i=0 ; i<_tb.size() ; i++){
        if(_tb[i].containPoint(mouse)){
            if(_tb[i].ifhasTurret()){

            }
        }
    }
}
void Chapter::drawHp(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(0,345,0,365),QString("GOLD : %1").arg(m_playerGold));
}
/*void Chapter::addWayPoints(){
    WayPoint *waypoint1 = new WayPoint(QPoint(1000,500));
    m_wayPontsList.push_back((waypoint1));

    WayPoint *waypoint2 = new WayPoint(QPoint(450,500));
    m_wayPontsList.push_back((waypoint2));
    waypoint2->setNextWayPoint(waypoint1);

    WayPoint *waypoint3 = new WayPoint(QPoint(450,400));
    m_wayPontsList.push_back((waypoint3));
    waypoint3->setNextWayPoint(waypoint2);

    WayPoint *waypoint4 = new WayPoint(QPoint(680,400));
    m_wayPontsList.push_back((waypoint4));
    waypoint4->setNextWayPoint(waypoint3);

    WayPoint *waypoint5 = new WayPoint(QPoint(680,50));
    m_wayPontsList.push_back((waypoint5));
    waypoint5->setNextWayPoint(waypoint4);

    WayPoint *waypoint6 = new WayPoint(QPoint(530,50));
    m_wayPontsList.push_back((waypoint6));
    waypoint6->setNextWayPoint(waypoint5);

    WayPoint *waypoint7 = new WayPoint(QPoint(530,230));
    m_wayPontsList.push_back((waypoint7));
    waypoint7->setNextWayPoint(waypoint6);

    WayPoint *waypoint8 = new WayPoint(QPoint(300,230));
    m_wayPontsList.push_back((waypoint8));
    waypoint8->setNextWayPoint(waypoint7);

    WayPoint *waypoint9 = new WayPoint(QPoint(300,50));
    m_wayPontsList.push_back((waypoint9));
    waypoint9->setNextWayPoint(waypoint8);

    WayPoint *waypoint10 = new WayPoint(QPoint(140,50));
    m_wayPontsList.push_back((waypoint10));
    waypoint10->setNextWayPoint(waypoint9);

    WayPoint *waypoint11 = new WayPoint(QPoint(140,350));
    m_wayPontsList.push_back((waypoint11));
    waypoint11->setNextWayPoint(waypoint10);

    WayPoint *waypoint12 = new WayPoint(QPoint(0,350));
    m_wayPontsList.push_back((waypoint12));
    waypoint12->setNextWayPoint(waypoint11);
}
*/
/*(0,350),(0,410),(150,410),(140,350),(150,100),(140,50)
(300,50),(300,100),(300,230),(300,280),
(530,230),(530,280),(530,100),(530,50),(680,100),(680,50),
(680,400),(680,350),(450,400),(450,350)(450,500)(450,550),
(1000,500),(1000,550)
*/

void Chapter::removedEnemy(Enemy *emy)
{
    Q_ASSERT(emy);
    m_enemyList.removeOne(emy);
    delete emy;
    if(m_enemyList.empty())
    {
        m_gameWin = true;
    }
}
void Chapter::getHpDamage(int damage)
{
    m_playerHp-= damage;
    if(m_playerHp <= 0)
    {
        doGameOver();
    }
}
void Chapter::doGameOver()
{
    if(!m_gameEnded)
    {
        m_gameEnded = true;
    }
}
void Chapter::enemyMove(){
    e.move();
    repaint();
}
void Chapter::on_pushButton_clicked(){
    e.canmove();
}
