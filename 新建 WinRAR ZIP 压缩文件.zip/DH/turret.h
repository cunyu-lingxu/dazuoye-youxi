#ifndef TURRET_H
#define TURRET_H

#include <QPixmap>
#include <QPainter>
#include <QPoint>
//60*75
class Turret
{
protected:
    QPoint _pos;

public:
    Turret(QPoint p);
    bool containPoint(QPoint &p);
};

class Turret1 : public Turret
{
private:
    QPixmap _pic;

public:
    Turret1(QPoint p);
    void draw(QPainter &painter);
};


#endif // TURRET_H
