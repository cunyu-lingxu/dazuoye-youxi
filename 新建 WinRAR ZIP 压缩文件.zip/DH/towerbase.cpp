#include "towerbase.h"

Towerbase::Towerbase(QPoint p) : _pos(p)
{
    _hasturret = false;
    _containmouse = false;
    _base = QPixmap(":/Tb/base2.png");
}

bool Towerbase::containPoint(QPoint &p){
    bool isXIn = (_pos.x()<p.x() && (_pos.x()+64)>p.x());
    bool isYIn = (_pos.y()<p.y() && (_pos.y()+64)>p.y());

    return (isXIn && isYIn);
}

void Towerbase::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _base);
}

void Towerbase::MouseEnter(){
    _containmouse = true;
    if(!_hasturret){
        _base = QPixmap(":/Tb/base1.png");
    }
    else{
        _base = QPixmap(":/Tb/base2.png");
    }
}

void Towerbase::MouseLeave(){
    _containmouse = false;
    _base = QPixmap(":/Tb/base2.png");
}

void Towerbase::setTurret(){
    _hasturret = true;
}

bool Towerbase::ifhasTurret(){
    return _hasturret;
}
