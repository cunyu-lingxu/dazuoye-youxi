#include "enemy.h"
#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QPixmap>
#include <QSize>
#include <QVector2D>
#include "waypoint.h"
#include "turret.h"
#include "chapter.h"
#include <QtMath>
#include <QMatrix>
#include "utility.h"

Enemy::Enemy(QPoint pos):
   m_pos(pos)
  ,m_active(false)
  ,m_maxHp(40)
  ,m_currentHp(40)
  ,m_walkingSpeed(1)
  ,m_ratationSprite(0)
{
    m_sprite = QPixmap(":/Tb/base1.png");
}

Enemy::~Enemy(){
    m_attackedTowersList.clear();

}

void Enemy::canmove(){
    m_active = true;
}

void Enemy::move()
{
    /*(0,350),(0,410),(150,410),(140,350),(150,100),(140,50)
    (300,50),(300,100),(300,230),(300,280),
    (530,230),(530,280),(530,100),(530,50),(680,100),(680,50),
    (680,400),(680,350),(450,400),(450,350)(450,500)(450,550),
    (1000,500),(1000,550)
    */


    /*if(!m_active)
        return;

    if(collisionWithCircle(m_pos,1,m_destinationWayPoint->pos(),1))
    {
        if(m_destinationWayPoint->nextWayPoint())
        {
        m_pos = m_destinationWayPoint->pos();
        m_destinationWayPoint = m_destinationWayPoint->nextWayPoint();

    }
    else
    {
        m_game->getHpDamage();
        m_game->removedEnemy(this);
        return;
    }
    }
    QPoint target = QPoint(300,350) ;

    qreal speed = m_walkingSpeed;
    QVector2D normalized(target - m_pos);
    normalized.normalize();
    m_pos = m_pos + normalized.toPoint() * speed;

    m_ratationSprite = qRadiansToDegrees(qAtan2(normalized.y(),normalized.x()))+180;
    */
    if(m_active = true){
        if(m_pos.x() < 140){
                m_pos = QPoint(m_pos.x()+5, m_pos.y());
            }
            else if(m_pos.x() == 140){
                if(m_pos.y() > 50){
                    _direction = 2;
                    m_pos = QPoint(m_pos.x(), m_pos.y()-5);
                }
                if(m_pos.y() == 50){
                    _direction = 1;
                    m_pos = QPoint(m_pos.x()-5, m_pos.y());
                }
            }

    }
}
void Enemy::draw(QPainter &painter) const
{
    /*if(!m_active)
        return;
        */


    /*QPoint healthBarPoint = m_pos + QPoint(-Health_Bar_Width / 2 - 5, -ms_fixedSize.height() / 3);
    // 绘制血条
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 2));
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint, QSize((double)m_currentHp / m_maxHp * Health_Bar_Width, 2));
    painter->drawRect(healthBarRect);*/

    //static const QPoint offsetPoint(-ms_fixedSize.width()/2,-ms_fixedSize.height()/2);
    /*painter.translate(m_pos);
    painter.rotate((m_ratationSprite));

    painter.drawPixmap(0,350,m_sprite);
    painter.restore();*/
    painter.drawPixmap(m_pos.x(),m_pos.y(),m_sprite);
}
QPoint Enemy::pos()
{
    return m_pos;

}
