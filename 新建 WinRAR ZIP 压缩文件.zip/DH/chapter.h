#ifndef CHAPTER_H
#define CHAPTER_H

#include <QMainWindow>
#include <QPainter>

#include <QMouseEvent>
#include "turret.h"
#include  <QList>
#include <QTime>
#include <QTimer>
#include "towerbase.h"
#include "enemy.h"



namespace Ui {
class Chapter;
}

class Chapter : public QMainWindow
{
    Q_OBJECT

public:
    explicit Chapter(QWidget *parent = 0);
    ~Chapter();

    void getHpDamage(int damage = 1);
    void removedEnemy(Enemy *emy);



protected slots:
    void enemyMove();

private slots:
    void on_pushButton_clicked();


protected:
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);

private:

    Ui::Chapter *ui;
    QPixmap _background,_Enemy;
    void loadTowerbase();
    QList<Towerbase> _tb;

    QList<Enemy *> m_enemyList;
    void addWayPoints();   //加入路径
    void drawHp(QPainter *painter);//画出血条
    void doGameOver();  //游戏结束
    int m_playerGold;  //金币
    int m_playerHp;    //血量
    bool m_gameEnded;
    bool m_gameWin;
    Enemy e;


};

#endif // CHAPTER_H
