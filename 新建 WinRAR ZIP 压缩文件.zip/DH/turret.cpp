#include "turret.h"

Turret::Turret(QPoint p) : _pos(p)
{

}

bool Turret::containPoint(QPoint &p){
    bool isXIn = (_pos.x()<p.x() && (_pos.x()+60)>p.x());
    bool isYIn = (_pos.y()<p.y() && (_pos.y()+75)>p.y());

    return (isXIn && isYIn);
}

Turret1::Turret1(QPoint p) : Turret(p)
{
    _pic = QPixmap(":/Turret/Turret1.png");
}

void Turret1::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _pic);
}
