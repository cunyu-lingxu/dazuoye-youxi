#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    //setMouseTracking(true);


    _background = QPixmap(":/Map/MAP.jpg");
    loadTowerbase();
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap adback = _background.scaled(960, 640, Qt::KeepAspectRatio);
    painter.drawPixmap(0, 0, adback);
    for(int i=0 ; i<_tb.size() ; i++){
        _tb[i].draw(painter);
    }
}

void Dialog::mouseMoveEvent(QMouseEvent *event){
    QPoint mouse = event->pos();

    for(int i=0 ; i<_tb.size() ; i++){
        if(_tb[i].containPoint(mouse)){
            _tb[i].MouseEnter();
        }
        else{
            _tb[i].MouseLeave();
        }
    }
}


void Dialog::loadTowerbase(){
    QPoint pos[] = {
        QPoint(218, 170),
        QPoint(380, 154),

        QPoint(444, 154),
        QPoint(608, 170),

        QPoint(218, 296),
        QPoint(608, 296),

        QPoint(218, 400),
        QPoint(356, 400),

        QPoint(520, 446),
        QPoint(670, 446),

        QPoint(755, 386),
        QPoint(62, 286)
    };

    int len = sizeof(pos)/sizeof(pos[0]);

    for(int i=0 ; i<len ; ++i){
        _tb.push_back(pos[i]);
    }
}


void Dialog::on_pushButton_clicked()
{
    emit sendSignal();
    this->close();
}
