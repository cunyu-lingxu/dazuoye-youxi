#include "turret.h"

bool Turret1::containPoint(QPoint &p){
    bool isXIn = (_pos.x()<p.x() && (_pos.x()+60)>p.x());
    bool isYIn = (_pos.y()<p.y() && (_pos.y()+75)>p.y());

    return (isXIn && isYIn);
}

QPoint Turret1::getPos(){
    return _pos;
}

int Turret1::getLevel(){
    return _level;
}

Turret1::Turret1(QPoint p, int t) : _pos(p), _type(t)
{
    _level = 1;

    switch(_type){
    case 1:
        _pic = QPixmap(":/Turret/Turret1-1.png");
        break;
    case 2:
        _pic = QPixmap(":/Turret/Turret2-1.png");
        break;
    case 3:
        _pic = QPixmap(":/Turret/Turret3-1.png");
        break;
    default:
        _pic = QPixmap(":/Turret/Turret4-1.png");
    }
}

void Turret1::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _pic);
}

void Turret1::upGrade(){
    if(_level == 1){
        _level += 1;
        switch(_type){
        case 1:
            _pic = QPixmap(":/Turret/Turret1-2.png");
            break;
        case 2:
            _pic = QPixmap(":/Turret/Turret2-2.png");
            break;
        case 3:
            _pic = QPixmap(":/Turret/Turret3-2.png");
            break;
        default:
            _pic = QPixmap(":/Turret/Turret4-2.png");
        }
        return;
    }

    if(_level == 2){
        _level += 1;
        switch(_type){
        case 1:
            _pic = QPixmap(":/Turret/Turret1-3.png");
            break;
        case 2:
            _pic = QPixmap(":/Turret/Turret2-3.png");
            break;
        case 3:
            _pic = QPixmap(":/Turret/Turret3-3.png");
            break;
        default:
            _pic = QPixmap(":/Turret/Turret4-3.png");
        }
        return;
    }
}
