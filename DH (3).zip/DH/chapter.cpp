#include "chapter.h"
#include "ui_chapter.h"

Chapter::Chapter(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Chapter)
{
    ui->setupUi(this);
    setMouseTracking(true);
    ui->centralwidget->setMouseTracking(true);

    _background = QPixmap(":/Map/MAP.jpg").scaled(960, 640, Qt::KeepAspectRatio);
    loadTowerbase();
    loadEnemy();

    enterSelection = false;
    enterUpgrade = false;
    _selection = QPixmap(":/Map/Selection.png");
    _upgrade = QPixmap(":/Button/UpgradeButton1.png").scaled(37.5, 75, Qt::KeepAspectRatio);
    _tpos = 0;

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(action()));
    timer->start(30);
}

Chapter::~Chapter()
{
    delete ui;
}

void Chapter::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0, 0, _background);
    for(int i=0 ; i<_tb.size() ; i++){
        _tb[i].draw(painter);
    }

    if(enterSelection){
        painter.drawPixmap(_tb[_tpos].getPos().x()-24.5, _tb[_tpos].getPos().y()-24.5, _selection);
    }

    for(int i=0 ; i<_t1.size() ; i++){
        _t1[i].draw(painter);
    }

    if(enterUpgrade){
        painter.drawPixmap(_t1[_tpos].getPos().x()+60, _t1[_tpos].getPos().y(), _upgrade);
    }

    for(int i=0 ; i<_e1.size() ; i++){
        _e1[i].draw(painter);
    }
}

void Chapter::mouseMoveEvent(QMouseEvent *event){
    QPoint mouse = event->pos();

    if(enterSelection){
        if(mouse.x()>(_tb[_tpos].getPos().x()-24.5) && mouse.x()<(_tb[_tpos].getPos().x()+32) && mouse.y()>(_tb[_tpos].getPos().y()-24.5) && mouse.y()<(_tb[_tpos].getPos().y()+32)){
            _selection = QPixmap(":/Map/Selection1.png");
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()+32) && mouse.x()<(_tb[_tpos].getPos().x()+88.5) && mouse.y()>(_tb[_tpos].getPos().y()-24.5) && mouse.y()<(_tb[_tpos].getPos().y()+32)){
            _selection = QPixmap(":/Map/Selection2.png");
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()-24.5) && mouse.x()<(_tb[_tpos].getPos().x()+32) && mouse.y()>(_tb[_tpos].getPos().y()+32) && mouse.y()<(_tb[_tpos].getPos().y()+88.5)){
            _selection = QPixmap(":/Map/Selection3.png");
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()+32) && mouse.x()<(_tb[_tpos].getPos().x()+88.5) && mouse.y()>(_tb[_tpos].getPos().y()+32) && mouse.y()<(_tb[_tpos].getPos().y()+88.5)){
            _selection = QPixmap(":/Map/Selection4.png");
        }
        else{
            _selection = QPixmap(":/Map/Selection.png");
        }
    }

    if(enterUpgrade){
        if(mouse.x()>(_t1[_tpos].getPos().x()+60) && mouse.x()<(_t1[_tpos].getPos().x()+97.5) && mouse.y()>(_t1[_tpos].getPos().y()) && mouse.y()<(_t1[_tpos].getPos().y()+37.5)){
            _upgrade = QPixmap(":/Button/UpgradeButton2.png").scaled(37.5, 75, Qt::KeepAspectRatio);
        }
        else if(mouse.x()>(_t1[_tpos].getPos().x()+60) && mouse.x()<(_t1[_tpos].getPos().x()+97.5) && mouse.y()>(_t1[_tpos].getPos().y()+37.5) && mouse.y()<(_t1[_tpos].getPos().y()+75)){
            _upgrade = QPixmap(":/Button/UpgradeButton3.png").scaled(37.5, 75, Qt::KeepAspectRatio);
        }
        else{
            _upgrade = QPixmap(":/Button/UpgradeButton1.png").scaled(37.5, 75, Qt::KeepAspectRatio);
        }
    }

    if(!enterSelection && !enterUpgrade)
    {
        for(int i=0 ; i<_tb.size() ; i++){
            if(_tb[i].containPoint(mouse)){
                _tb[i].MouseEnter();
            }
            else{
                _tb[i].MouseLeave();
            }
        }
    }

    update();
}


void Chapter::loadTowerbase(){
    QPoint pos[] = {
        QPoint(218, 170),
        QPoint(380, 154),

        QPoint(444, 154),
        QPoint(608, 170),

        QPoint(218, 296),
        QPoint(608, 296),

        QPoint(218, 400),
        QPoint(356, 400),

        QPoint(520, 446),
        QPoint(670, 446),

        QPoint(755, 386),
        QPoint(62, 286)
    };

    int len = sizeof(pos)/sizeof(pos[0]);

    for(int i=0 ; i<len ; ++i){
        _tb.push_back(pos[i]);
    }
}

void Chapter::mousePressEvent(QMouseEvent *event){
    QPoint mouse = event->pos();

    int x = _tb[_tpos].getPos().x()+2;
    int y = _tb[_tpos].getPos().y()-28;

    if(enterSelection){
        if(mouse.x()>(_tb[_tpos].getPos().x()-24.5) && mouse.x()<(_tb[_tpos].getPos().x()+32) && mouse.y()>(_tb[_tpos].getPos().y()-24.5) && mouse.y()<(_tb[_tpos].getPos().y()+32)){
            Turret1 t1(QPoint(x, y), 1);
            _t1.push_back(t1);
            _tb[_tpos].setTurret();
            _t1[_t1.size()-1]._tb = &_tb[_tpos];
            enterSelection = false;
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()+32) && mouse.x()<(_tb[_tpos].getPos().x()+88.5) && mouse.y()>(_tb[_tpos].getPos().y()-24.5) && mouse.y()<(_tb[_tpos].getPos().y()+32)){
            Turret1 t2(QPoint(x, y), 2);
            _t1.push_back(t2);
            _tb[_tpos].setTurret();
            _t1[_t1.size()-1]._tb = &_tb[_tpos];
            enterSelection = false;
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()-24.5) && mouse.x()<(_tb[_tpos].getPos().x()+32) && mouse.y()>(_tb[_tpos].getPos().y()+32) && mouse.y()<(_tb[_tpos].getPos().y()+88.5)){
            Turret1 t3(QPoint(x, y), 3);
            _t1.push_back(t3);
            _tb[_tpos].setTurret();
            _t1[_t1.size()-1]._tb = &_tb[_tpos];
            enterSelection = false;
        }
        else if(mouse.x()>(_tb[_tpos].getPos().x()+32) && mouse.x()<(_tb[_tpos].getPos().x()+88.5) && mouse.y()>(_tb[_tpos].getPos().y()+32) && mouse.y()<(_tb[_tpos].getPos().y()+88.5)){
            Turret1 t4(QPoint(x, y), 4);
            _t1.push_back(t4);
            _tb[_tpos].setTurret();
            _t1[_t1.size()-1]._tb = &_tb[_tpos];
            enterSelection = false;
        }
        else{
            enterSelection = false;
        }
    }


    if(enterUpgrade){
        if(enterUpgrade){
            if(mouse.x()>(_t1[_tpos].getPos().x()+60) && mouse.x()<(_t1[_tpos].getPos().x()+97.5) && mouse.y()>(_t1[_tpos].getPos().y()) && mouse.y()<(_t1[_tpos].getPos().y()+37.5)){
                _t1[_tpos].upGrade();
                enterUpgrade = false;
            }
            else if(mouse.x()>(_t1[_tpos].getPos().x()+60) && mouse.x()<(_t1[_tpos].getPos().x()+97.5) && mouse.y()>(_t1[_tpos].getPos().y()+37.5) && mouse.y()<(_t1[_tpos].getPos().y()+75)){
                _t1[_tpos]._tb->removeTurret();
                _t1.removeAt(_tpos);
                enterUpgrade = false;
            }
            else{
                enterUpgrade = false;
            }
        }
    }

    if(!enterSelection && !enterUpgrade){
        for(int i=0 ; i<_tb.size() ; i++){
            if(_tb[i].containPoint(mouse)){
                if(!_tb[i].ifhasTurret()){
                    enterSelection = true;
                    _tpos = i;
                }
            }
        }

        for(int i=0 ; i<_t1.size() ; i++){
            if(_t1[i].containPoint(mouse)){
                enterUpgrade = true;
                _tpos = i;
            }
        }

    }
    update();
}

void Chapter::loadEnemy(){
    QPoint pos[] = {
        QPoint(0, 350),
        QPoint(-60, 350),
        QPoint(-120, 350),
        QPoint(-180, 350),
        QPoint(-240, 350)
        //QPoint(-110, 400)
    };

    int len = sizeof(pos)/sizeof(pos[0]);

    for(int i=0 ; i<len ; ++i){
        _e1.push_back(pos[i]);
    }
}

void Chapter::action(){
    for(int i=0 ; i<_e1.size() ;i++){
        _e1[i].move();
    }
    repaint();
}
