#include "enemy.h"

Enemy::Enemy(QPoint p) : _pos(p)
{
    _direction = 1;
}


Enemy1::Enemy1(QPoint p) : Enemy(p)
{
    _pic = QPixmap(":/Enemy/Tank1.png");
}

void Enemy1::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _pic);
}

void Enemy1::exchangDirection(int i){
    switch(i){
    case 1:
        _pic = QPixmap(":/Enemy/Tank1.png");
        break;
    case 2:
        _pic = QPixmap(":/Enemy/Tank2.png");
        break;
    case 3:
        _pic = QPixmap(":/Enemy/Tank3.png");
        break;
    default:
        _pic = QPixmap(":/Enemy/Tank4.png");
    }
}

void Enemy1::move(){
    if(_pos.y()==350 && _pos.x()<140)
    {
        exchangDirection(1);
        _pos = QPoint(_pos.x()+1, _pos.y());
    }
    else if(_pos.x()==140 && _pos.y()<=350 && _pos.y()>50)
    {
        exchangDirection(3);
        _pos = QPoint(_pos.x(), _pos.y()-1);
    }
    else if(_pos.y()==50 && _pos.x()>=140 && _pos.x()<300)
    {
        exchangDirection(1);
        _pos = QPoint(_pos.x()+1, _pos.y());
    }
    else if(_pos.x()==300 && _pos.y()>=50 && _pos.y()<230)
    {
        exchangDirection(4);
        _pos = QPoint(_pos.x(), _pos.y()+1);
    }
    else if(_pos.y()==230 && _pos.x()>=300&& _pos.x()<530)
    {
        exchangDirection(1);
        _pos = QPoint(_pos.x()+1, _pos.y());
    }
    else if(_pos.x()==530 && _pos.y()>50 && _pos.y()<=230)
    {
        exchangDirection(3);
        _pos = QPoint(_pos.x(), _pos.y()-1);
    }
    else if(_pos.y()==50 && _pos.x()>=530 && _pos.x()<680)
    {
        exchangDirection(1);
        _pos = QPoint(_pos.x()+1, _pos.y());
    }
    else if(_pos.x()==680 && _pos.y()>=50 && _pos.y()<400)
    {
        exchangDirection(4);
        _pos = QPoint(_pos.x(), _pos.y()+1);
    }
    else if(_pos.y()==400 && _pos.x()>450 && _pos.y()<=680)
    {
        exchangDirection(2);
        _pos = QPoint(_pos.x()-1, _pos.y());
    }
    else if(_pos.x()==450 && _pos.y()>=400 && _pos.y()<500)
    {
        exchangDirection(4);
        _pos = QPoint(_pos.x(), _pos.y()+1);
    }
    else if(_pos.y()==500 && _pos.x()>=450 && _pos.y()<1000)
    {
        exchangDirection(1);
        _pos = QPoint(_pos.x()+1, _pos.y());
    }

}
/*(0,350),(0,410),(150,410),(140,350),(150,100),(140,50)
(300,50),(300,100),(300,230),(300,280),
(530,230),(530,280),(530,100),(530,50),(680,100),(680,50),
(680,400),(680,350),(450,400),(450,350)(450,500)(450,550),
(1000,500),(1000,550)
*/
