#ifndef TOWERBASE_H
#define TOWERBASE_H


#include <QPoint>
#include <QPainter>
#include <QPixmap>

class Towerbase
{
private:
    QPoint _pos;
    QPixmap _base;
    bool _hasturret;
    bool _containmouse;

public:
    Towerbase(QPoint p);
    bool containPoint(QPoint &p);
    void draw(QPainter &painter);
    void MouseEnter();
    void MouseLeave();
    void setTurret();
    void removeTurret();
    bool ifhasTurret();
    QPoint getPos();


};

#endif // TOWERBASE_H
