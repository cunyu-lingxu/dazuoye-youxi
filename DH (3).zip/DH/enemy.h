#ifndef ENEMY_H
#define ENEMY_H

#include <QPoint>
#include <QPixmap>
#include <QPainter>

class Enemy
{
protected:
    QPoint _pos;
    int _direction;//1向右 2向上 3向下

public:
    Enemy(QPoint p);
};

class Enemy1 : public Enemy{
private:
    QPixmap _pic;

public:
    Enemy1(QPoint p);
    void draw(QPainter &painter);
    void move();
    void exchangDirection(int i);
};




#endif // ENEMY_H
