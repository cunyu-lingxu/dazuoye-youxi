#ifndef TURRET_H
#define TURRET_H

#include <QPixmap>
#include <QPainter>
#include <QPoint>
#include "towerbase.h"
//60*75
class Turret
{};

class Turret1 : public Turret
{
private:
    QPixmap _pic;
    QPoint _pos;
    int _level;
    int _type;

public:
    Turret1(QPoint p, int t);
    void draw(QPainter &painter);
    void upGrade();
    bool containPoint(QPoint &p);
    QPoint getPos();
    int getLevel();
    Towerbase *_tb;


};


#endif // TURRET_H
