#ifndef CHAPTER_H
#define CHAPTER_H

#include <QMainWindow>
#include <QPainter>
#include <towerbase.h>
#include <QMouseEvent>
#include <QTimer>
#include "turret.h"
#include "enemy.h"

namespace Ui {
class Chapter;
}

class Chapter : public QMainWindow
{
    Q_OBJECT

public:
    explicit Chapter(QWidget *parent = 0);
    ~Chapter();

protected:
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);

private:
    Ui::Chapter *ui;
    QPixmap _background;
    QPixmap _selection, _upgrade;

    bool enterSelection;
    bool enterUpgrade;
    QList<Towerbase> _tb;
    QList<Turret1> _t1;
    int _tpos;

    QList<Enemy1> _e1;

    void loadTowerbase();
    void loadEnemy();

private slots:
    void action();
};

#endif // CHAPTER_H
