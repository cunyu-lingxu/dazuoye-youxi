#ifndef GUARD_H
#define GUARD_H

#include <QPoint>
#include "towerpos.h"
#include <QPainter>
#include <QPixmap>
#include "enemy.h"
#include <QObject>
#include <math.h>

class Guard{//警卫
public:
    Guard() {}
    Guard(QPoint pos);
    void draw(QPainter &painter);
    void setPos(QPoint pos);//设置中点
    QPoint getPos();//得到点
    QPoint getcenterPos();//得到中点
    bool containPoint(QPoint &pos);//进没有进来
    bool isInAttackRange(Enemy *e);//在不在攻击范围里
    void attack();//攻击

private:
    QPoint _pos;//中点
    QPixmap _type;//图片
    Enemy *_target;//敌人目标
    bool _hasTarget;//有没有敌人
    double _RotationAngle;//旋转角度
};

#endif // GUARD_H
