#include "enemy.h"

Enemy::Enemy(QPoint pos) :
    _pos(pos)
{
    _pic = QPixmap(":/Enemy/Enemy1.png");//敌人图片
    _canmove = false;
}

void Enemy::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _pic);
}

void Enemy::move(){
   if(_canmove == true){
        if(_pos.y()>0){
            QPoint p(_pos.x(), _pos.y()-1);
            _pos = p;
        }
    }
}
void Enemy::canmove(){
    _canmove = true;
}

void Enemy::stopmove(){
    _canmove = false;
}

QPoint Enemy::getcenterPos(){
    return QPoint(_pos.x()+25, _pos.y()+25);
}
