#include "guard.h"

Guard::Guard(QPoint pos) :
    _pos(pos)
{
    _type = QPixmap(":/Tower/Tower1.png");
    _target = NULL;//指针类型的
    _hasTarget = false;//bool型
    _RotationAngle = 0;
}


void Guard::draw(QPainter &painter){
    painter.save();//save() 用于保存 QPainter 的状态，restore() 用于恢复 QPainter 的状态，
                    //save() 和 restore() 一般都是成对使用的，如果只调用了 save() 而不调用 restore()，那么保存就没有意义了，保存是为了能恢复被保存的状态而使用的。
                    //QPainter 的状态有画笔，画刷，字体，变换（旋转，移动，切变，缩放）等。
    QPixmap fittype = _type.scaled(50, 50, Qt::KeepAspectRatio);//图片的缩放(后面的保留字是按比例缩放的意思)
                                                                //如何在改变窗口组件的情况下改变窗口背景图片的大小，我们通常会使用Qt自带的scaled()函数；
                                                                //QImage、QPixmap等绘图设备类都提供scaled()函数。
    painter.translate(getcenterPos().x(), getcenterPos().y());//设置坐标原点
    painter.rotate(_RotationAngle);//旋转
    painter.translate(-getcenterPos().x(), -getcenterPos().y());//设置坐标原点
    painter.drawPixmap(_pos.x(), _pos.y(), fittype);//显示图片
    painter.restore();//恢复OPainter状态,成对使用
    /*if(_containMouse){
        painter.drawEllipse(getcenterPos().x()-100, getcenterPos().y()-100, 200, 200);

    }
    painter.setPen(QPen(Qt::red));
    if(_hasTarget)
        painter.drawLine(_target->getcenterPos().x(), _target->getcenterPos().y(), getcenterPos().x(), getcenterPos().y());
    painter.setPen(QPen(Qt::black));*/

}
void Guard::setPos(QPoint pos)//:_pos(pos) 只有构造函数可以进行初始化列表
{
    _pos = pos;
}

QPoint Guard::getPos(){
    return _pos;
}

QPoint Guard::getcenterPos(){
    return QPoint(_pos.x()+25, _pos.y()+25);//得到几何中点
}

bool Guard::containPoint(QPoint &pos){//注意是引用
    bool isXIn = (_pos.x()<pos.x() && (_pos.x()+50)>pos.x());
    bool isYIn = (_pos.y()<pos.y() && (_pos.y()+50)>pos.y());
    return (isXIn && isYIn);
}//判断敌人的中点是不是进入了炮塔的范围里（开始的时候的判断）

bool Guard::isInAttackRange(Enemy *e){
    int x = (e->getcenterPos().x()-getcenterPos().x());
    int y = (e->getcenterPos().y()-getcenterPos().y());
    if((x*x + y*y) <= 10000){//攻击距离
        _hasTarget = true;
        _target = e;
        return true;
    }
    else{
        _hasTarget = false;
        _target = NULL;
    }
    return false;
}//判断在不在攻击范围内

void Guard::attack(){
    if(_hasTarget){
        _RotationAngle += 1;
    }
}
