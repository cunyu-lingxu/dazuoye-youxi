#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QImage>
#include <QSize>
#include <vector>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    e(QPoint(250, 550))
{
    ui->setupUi(this);
    loadTowerPos();

    connect(ui->pushButton, SIGNAL(clicked(bool)), this, SLOT(on_pushButton_clicked()));

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(EnemyMove()));
    timer->start(20);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,QPixmap(":/Map/map2.png"));
    for(int i=0 ; i<Tpos.size() ; i++){
        Tpos[i].draw(painter);//画塔
    }
    e.draw(painter);
    for(int i=0 ; i<_Guard.size() ; i++){
        Enemy *en = &e;
        _Guard[i].isInAttackRange(en);
        _Guard[i].draw(painter);
    }
}


void MainWindow::loadTowerPos(){
    QPoint pos[] = {
        QPoint(195, 200),
        QPoint(195, 400),

        QPoint(305, 200),
        QPoint(305, 400)
    };
    int len = sizeof(pos)/sizeof(pos[0]);//得到多少个点
    for(int i=0 ; i<len ; ++i){
        Tpos.push_back(pos[i]);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    QPoint pressPos = event->pos();//鼠标读取当前位置
    if(event->button() == Qt::LeftButton){//点击左键
        for(int i=0 ; i<Tpos.size() ; i++){
            if(Tpos[i].containPoint(pressPos) && !Tpos[i].hasGuard()){
                Tpos[i].setGuard();
                _Guard.push_back(Tpos[i].getPos());//从链表最后新加入一个元素
                update();//更新数据
            }
        }
    }
    if(event->button() == Qt::RightButton){
        for(int i=0 ; i<Tpos.size() ; i++){
            if(Tpos[i].containPoint(pressPos) && Tpos[i].hasGuard()){
                Tpos[i].removeGuard();
                for(int j=0 ; j<_Guard.size() ; j++){
                    if(_Guard[j].containPoint(pressPos)){
                        _Guard.removeAt(j);
                        update();
                    }
                }
            }
        }
    }
}

void MainWindow::EnemyMove(){
    e.move();
    for(int i=0 ; i<_Guard.size() ; i++){
        _Guard[i].attack();
    }
    repaint();//重置画面//前面转了一度，需要重新绘制画面
}

void MainWindow::on_pushButton_clicked()
{
    e.canmove();
}

void MainWindow::on_pushButton_2_clicked()
{
    e.stopmove();
}
