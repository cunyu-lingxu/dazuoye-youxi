#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>//QObject 是所有Qt对象的基类。它的最主要特征是关于对象间无缝通信的机制：信号与槽。
                   //使用connect()建立信号到槽的连接，使用disconnect()销毁连接，
                    //使用blockSignals()暂时阻塞信号以避免无限通知循环，使用connectNotify()和disconnectNotify()追踪连接。
#include <QPoint>
#include <QPainter>
#include <QPixmap>//实现在窗口上显示图片，并将图片进行平移，缩放，旋转和扭曲。这里我是利用QPixmap类来实现图片显示的。
class Enemy : public QObject{
public:
    Enemy(){}
    Enemy(QPoint pos);//QPoint类定义了平面上的一个点
    void draw(QPainter &painter);//QPainter包含三个主要的设置，分别为画笔QPen，画刷QBrush和字体QFont
    void move();
    void canmove();
    void stopmove();
    QPoint getcenterPos();//得到图片中点

private:
    QPoint _pos;//点
    QPixmap _pic;//图片
    bool _canmove;
};

#endif // ENEMY_H
